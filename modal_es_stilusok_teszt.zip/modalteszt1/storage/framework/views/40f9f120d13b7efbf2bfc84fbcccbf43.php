<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/mystyle.css')); ?>">
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modal.js')); ?>"></script>
</head>
<body data-theme="dark" class="container">
    <h1>Lorem, ipsum.</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolore praesentium alias impedit sint autem eius nobis saepe nihil minus ipsam fugit reiciendis esse aperiam voluptatum voluptas quas, nostrum tenetur eveniet!</p>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal1">
        Launch demo modal
    </button>
    <div>
        <p>asd</p>
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
              Téma kiválasztása
            </button>
            <ul class="dropdown-menu">
              <li><button class="dropdown-item" type="button" onclick="ModeSelect('light')">Világos</button></li>
              <li><button class="dropdown-item" type="button" onclick="ModeSelect('dark')">Sötét</button></li>
              <li><button class="dropdown-item" type="button" onclick="ModeSelect('blue')">Kék</button></li>
              <li><button class="dropdown-item" type="button" onclick="ModeSelect('orange')">Narancs</button></li>
            </ul>
        </div>
    </div>
    <div class="color-bg-primary py-5 rounded-3 my-1">
        <p>Lorem ipsum dolor sit amet.</p>
    </div>
    <div class="color-bg-secondary py-5 rounded-3 my-1">
        <p>Lorem ipsum dolor sit amet.</p>
    </div>
    <div class="color-bg-accent py-5 rounded-3 my-1">
        <p>Lorem ipsum dolor sit amet.</p>
    </div>

    <div class="modal" id="modal1" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Elvetés</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Biztosan elveti?</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Mégsem</button>
              <button type="button" class="btn btn-primary">Elvetés</button>
            </div>
          </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\olah.bence\Desktop\modalteszt\modalteszt1\resources\views/welcome.blade.php ENDPATH**/ ?>