

function DarkMode(){
    document.body.setAttribute("data-theme", "blue");
}

function ModeSelect(name){
    switch (name){
        case "light":
            document.body.setAttribute("data-theme", "light");
            return;
        case "dark":
            document.body.setAttribute("data-theme", "dark");
            return;
        case "blue":
            document.body.setAttribute("data-theme", "blue");
            return;
        case "orange":
            document.body.setAttribute("data-theme", "orange");
            return;
    }
}


